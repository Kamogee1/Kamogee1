import { View, Text } from 'react-native'
import React from 'react'

const asset = () => {
  return (
    <View>
      <Text>asset</Text>
    </View>
  )
}

export default asset