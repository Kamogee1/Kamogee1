// Get the button element
var getStartedBtn = document.getElementById("btn-login");

// When the user clicks the button, redirect to the next HTML page
getStartedBtn.onclick = function() {
  // Replace "next_page.html" with the path to the next HTML page
  window.location.href = "Ceasercipher.html";
}